<?php include"../conectar.php";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" type="image/x-icon" href="imagenes/logo.png"/>
<link href="estilos.css" rel="stylesheet" type="text/css" />
<title>MINEC</title>
</head>

<body>
<center>
<table width="1000"  height="110" border="0" cellspacing="0" cellpadding="0" id="tabla_c_encabezado">
  <tr>
    <td width="150" align="center"><img src="img/MINEC.png" width="98" height="88"/></td>
    <td width="350" align="left"><img src="img/titulo.png" width="360" height="98"/></td>
    <td width="250" align="center" valign="bottom">
    	<img src="imagenes/icono_estudiante.png" width="100" height="100"/><br />
        <font size="5" color="#FF0000">Sección de Estudiantes</font></td>
    
  </tr>
</table>
<hr  color="#0066FF" width="1000"/>
    
    
   		<table width="1000" border="0" cellspacing="0" cellpadding="0" id="tabla_menu" >
 			 <tr>
   				<td align="left" height="30">
				<?php include('menu.php'); ?>
                </td>
    		</tr>
		</table>
        

 
    

<br />
</center>
</body>
</html>