<?php include ("encabezado.php")?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" type="image/x-icon" href="imagenes/logo.jpg.png"/>
<link href="estilos.css" rel="stylesheet" type="text/css" />
<link href="estilos8.css" rel="stylesheet" type="text/css" />
<title>Distrito Metropolitano</title>
</head>

<body>
<center>
 <table border="0" cellspacing="0" cellpadding="0" id="table_c">
  <tr>
    <td width="750" valign="top" align="center"><?php include('estudiante/p_estudiante_buscar_nombre.php'); ?></td>
        <td width="250" valign="top"><div id="formulario"></div></td>

  </tr>
</table>
</center>

</body>
</html>
<?php include ("../pie.php")?>

