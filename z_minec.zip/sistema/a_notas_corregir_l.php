<?php include ("encabezado.php")?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" type="image/x-icon" href="imagenes/logo.jpg.png"/>
<link href="estilos.css" rel="stylesheet" type="text/css" />
<title>Distrito Metropolitano</title>
</head>

<body>
<center>
 <table border="0" cellspacing="0" cellpadding="0" id="table_c">
  <tr>
    <td width="750" valign="top" align="center"><?php include('notas/p_notas_corregir_l.php'); ?></td>
        <td width="250" valign="top"><div id="formulario"> 
        <font id="texto">
        <table width="200" border="1" cellspacing="3" cellpadding="0">
        	<tr>
            	<td colspan="2" align="center"><font id="sub_titulo">Tabla de Calificación</font></td>
            </tr>
        	<tr>
            	<td width="75" align="center">Punto:</td>
                <td width="75" align="center">Porcentaje:</td>
            </tr>
            <tr>
            	<td align="center">20 Pts</td>
                <td align="center">100%</td>
            </tr>
            <tr>
            	<td align="center">19 Pts</td>
                <td align="center">95%</td>
            </tr>
            <tr>
            	<td align="center">18 Pts</td>
                <td align="center">90%</td>
            </tr>
            <tr>
            	<td align="center">17 Pts</td>
                <td align="center">85%</td>
            </tr>
            <tr>
            	<td align="center">16 Pts</td>
                <td align="center">80%</td>
            </tr>
            <tr>
            	<td align="center">15 Pts</td>
                <td align="center">75%</td>
            </tr>
            <tr>
            	<td align="center">14 Pts</td>
                <td align="center">70%</td>
            </tr>
            <tr>
            	<td align="center">13 Pts</td>
                <td align="center">65%</td>
            </tr>
            <tr>
            	<td align="center">12 Pts</td>
                <td align="center">60%</td>
            </tr>
            <tr>
            	<td align="center">11 Pts</td>
                <td align="center">55%</td>
            </tr>
            <tr>
            	<td align="center">10 Pts</td>
                <td align="center">50%</td>
            </tr>
            <tr>
            	<td align="center">09 Pts</td>
                <td align="center">45%</td>
            </tr>
            <tr>
            	<td align="center">08 Pts</td>
                <td align="center">40%</td>
            </tr>
            <tr>
            	<td align="center">07 Pts</td>
                <td align="center">35%</td>
            </tr>
            <tr>
            	<td align="center">06 Pts</td>
                <td align="center">30%</td>
            </tr>
            <tr>
            	<td align="center">05 Pts</td>
                <td align="center">25%</td>
            </tr>
            <tr>
            	<td align="center">04 Pts</td>
                <td align="center">20%</td>
            </tr>
            <tr>
            	<td align="center">03 Pts</td>
                <td align="center">15%</td>
            </tr>
            <tr>
            	<td align="center">02 Pts</td>
                <td align="center">10%</td>
            </tr>
            <tr>
            	<td align="center">01 Pts</td>
                <td align="center">5%</td>
            </tr>
            
        </table>
        </font>
        </div></td>

  </tr>
</table>	
</center> 
</body>
</html>
<?php include ("../pie.php")?>
