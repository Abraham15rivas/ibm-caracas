<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tambla de imprimir</title>
<style>


body{
		margin: 0px; 
		font-family: "Times New Roman", Times, serif, cursive;
	}
h1{
	font-size: 12px; 
	font-weight: bold; /*Negrillas*/
	font-variant: normal
	
	}	
#texto_1{
	position:relative;
	font-size: 14px; 
	font-style: italic;
	font-weight: bold; /*Negrillas*/
	font-variant: normal;
	color: #000;
	filter: Glow(Color=#333333, Strength=3);
	text-indent: 15px;
	}	


</style>
</head>


<body>
<center>
<table width="290" height="460" border="0"  cellspacing="0" cellpadding="7">
	<tr height="60">
    	<td width="100%"  valign="top">
        	<img src="img/adv.png" width="55" height="60"  style="float:left" />
        	<img src="img/minec.png" width="59" height="59" style="float:right" />
        </td>
    </tr>

  <tr height="50">
    <td align="center" valign="top" >
        <h1>REPÚBLICA BOLIVARIANA DE VENEZUELA</br>
		F.C.G. ASAMBLEAS DE DIOS<br/>
        MINISTERIO DE EDUCACIÓN CRISTIANA<br />
        INSTITUTO BÍBLICO ALFA Y OMEGA<br /></h1>
        </td>
 </tr>
 
 <tr height="90">
        <td align="justify" valign="top">
        
        <font id="texto_1">
        Este carnet es propiedad del Instituto Bíblico Alfa y Omega.
        La dirección de esta institución certífica que el portador, ESTUDIA actualmente en esta institución, por tal motivo se le agradece a las autoridades civiles, militares y políticas la colaboración al titular de esta identificación.  
        
        </font>
         
    </td>
  </tr>       
 <tr height="70">
        <td align="center" valign="top">
        <br />
        <img src="img/firma_ibao.png" width="225" height="75" />
        <br />
        <br />
        <font size="2"><strong>Telefonos:(+58) 0416-611-7761 / 0424-141-0754</strong></font>
        
        
    </td>
  </tr>
</table>
</center>
</body>
</html>