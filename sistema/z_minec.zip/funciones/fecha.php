<?php 
echo date("F-d-M-Y");


echo $d;
echo hola;



function CrearFecha($FechaUS){
	list ($dia, $mes, $año) = split("-",$FechaUS);
	
	return    $dia. ' días del mes de '.NombreMes($mes).' del '.$año; 
}

function NombreMes($numMes){
	switch ($numMes){
		case 01:
			return "Enero";
			break;
		case 02:
			return "Febrero";
			break;
		case 03:
			return "Marzo";
			break;
		case 04:
			return "Abril";
			break;
		case 05:
			return "Mayo";
			break;
		case 06:
			return "Junio";
			break;
		case 07:
			return "Julio";
			break;
		case 08:
			return "Agosto";
			break;
		case 09:
			return "Septiembre";
			break;
		case 10:
			return "Octubre";
			break;
		case 11:
			return "Noviembre";
			break;
		case 12:
			return "Diciembre";
			break;
		
		}
	
	
}

echo CrearFecha(date("d - M - Y"));	





?>

