<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Carnet</title>
<style>

body{
		margin: 1px 0px;
		font-family:Arial, Helvetica, sans-serif;
		
		}  
#texto_p{
	font-size: 13px;
	font-family:'Arial Black', Gadget, sans-serif;
	font-weight: bold; 
	
	}		
	
#titulo{
	font-size: 9px; 
	font-style: italic; /*cursiva*/
	font-weight: bold; /*Negrillas*/
	font-variant: normal
	 }	
	 
#texto_1{
	position:relative;
	font-size: 16px; 
	font-style: italic;
	font-weight: bold; 
	font-variant: normal;
	color: #FFF;
	filter: Glow(Color=#333333, Strength=3);
	text-shadow:
   -2px -2px 0 #000,
    2px -2px 0 #000,
   -2px 2px 0 #000,
    2px 2px 0 #000;	
	}	
	
#texto_2{
	position:relative;
	font-size: 14px; 
	font-style: italic;
	font-weight: bold; 
	font-variant: normal;
	color:#000;

	
	}

#cuadro{
	width:100%;
	background:#CCC;
	float:none;
	text-indent: 15px;
-webkit-box-shadow: 10px -8px 5px -6px rgba(0,0,0,0.75);
-moz-box-shadow: 10px -8px 5px -6px rgba(0,0,0,0.75);
box-shadow: 10px -8px 5px -6px rgba(0,0,0,0.75);
	
	
	
	}	
			  
</style>
</head>


<body>
 <?php
	error_reporting(0); 
	if($_POST['cedula']){
	include"../../conectar.php";
	$sql="select * from estudiante where cedula='$_POST[cedula]'";
	$consulta=mysql_query($sql,$conexion);
		if(list($id_estudiante,$l_cedula,$cedula,$nombre_1,$nombre_2,$apellido_1,$apellido_2,$telefono,$correo,$instituto,$extension,$modalidad,$curso,$nivel,$estatus,$codigo_diploma,$fecha_nacimiento,$fecha_ingreso,$fecha_egreso,$nivel_graduacion,$observaciones,$carta_del_pastor,$diezmo_ofrenda,$planilla_de_inscripcion,$copia_de_cedula,$fotos_tipo_carnet,$copia_de_titulo,$certificacion_notas,$salud_mental,$sobre_de_manila,$iglesia,$pastor)=mysql_fetch_array($consulta))	
	{
?>  
<center>
<table width="300" height="476" border="0" cellpadding="0" cellspacing="0" background="img/fondo_carnet.jpg">
	<tr height="65">
    	<td align="center" colspan="3"><div><img src="img/encabezado_ibme.png" width="296" height="58" /></div></td>
    </tr>
   
    
    
<tr height="175">
	<td width="40" align="center"></td>
    <td width="180"align="center">
    <div><img src="../../foto/<?php echo $cedula ?>.jpg" width="120" height="152"  style="border-radius: 20px; "/></div>
    <strong>
    <img src="img/estudiate.png" width="132" height="18" />
  	</td>
    <td width="40" align="center"></td>
</tr>




<tr height="130">
	<td></td>
    <td align="left">
   <font id="texto_p">
    	Nombres:<br />
        <font id="texto_2">
        <div id="cuadro"><?php echo strtoupper ($nombre_1) ?> <?php echo strtoupper ($nombre_2) ?></div>
        </font>
       	Apellidos:<br />
        <font id="texto_2">
        <div id="cuadro"> <?php echo strtoupper ($apellido_1) ?> <?php echo strtoupper ($apellido_2) ?></div>
        </font>
        CI:<br />
		<font id="texto_2">
		<div id="cuadro"><?php echo $cedula ?></div>
        </font>
        Nivel:<br />
        <font id="texto_2">
		<div id="cuadro"><?php echo strtoupper ($curso) ?></div>
      </font> 
     </font> 
     
  	</td>
    <td></td>
</tr>



    
     
  <tr height="20">
     <td align="center" valign="bottom" colspan="3"> 
    <div style="width:179px; height:48px; background-color:#FFF; position:relative;"><img src='http://barcode.tec-it.com/barcode.ashx?translate-esc=off&data=<?php echo $cedula?>&code=Code25IL&unit=Fit&dpi=96&imagetype=Gif&rotation=0&color=000000&bgcolor=FFFFFF&qunit=Mm&quiet=0' alt='Barcode Generator TEC-IT'/>
	 </div>
      
  		<div style="width:310px; height:30px;  position:relative; text-shadow:#000">
       	<table width="100%" border="0" bgcolor="#CCCCCC" >
  			<tr>
    			<td align="center" height="25" valign="middle">
                <font size="2">
       				<strong> VENCE: MARZO/2018</strong>
        		</font>
                </td>
             </tr>
			</table>
        </div>
     
     </td>
  
  </tr>
</table>



<?php 
	}else{
		print"Dato no encontrado"; ?> <script> alert ("Datos no encontrados")</script>

<?php
	}mysql_close($conexion);
	}
?>	
</center>

</body>
</html>