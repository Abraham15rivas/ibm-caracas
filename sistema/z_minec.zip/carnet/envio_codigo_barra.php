<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>generador de Codigo de Barra</title>
</head>

<body>
<form action="codigo_barra/codigo_barra.php" method="post">
Igresar el codigo de barra:
<input name="cedula" type="text"/>
<input  type="submit" value="Enviar"/>

</form>


</body>
</html>