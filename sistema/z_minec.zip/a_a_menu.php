<?php include ("encabezado.php")?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="estilos.css" rel="stylesheet" type="text/css" />
<title>Distrito Metropolitano</title>
</head>


<body>
<center>
 <table  border="0" cellspacing="0" cellpadding="0" id="table_c">
  <tr>
    <td width="750" valign="top" align="left">
    	
       <table width="750" border="0" cellspacing="0" cellpadding="0">
		      <tr height="250">
    				<td width="750" align="center" valign="top">
                    <img src="imagenes/MINEC.png" width="148" height="128"/><br /><br />
                    <font id="titulo">SANECAD</font>
                        
					</td>
  				</tr>
  				<tr height="400">
    				<td width="750" align="left"  valign="top">
                        <font id="titulo"> SISTEMA AUTOMATIZADO NACIONAL</font><br />
    					<font id="sub_titulo">DE EDUCACION CRISTIANA DE LAS ASAMBLEAS DE DIOS DE VENEZUELA</font><br /><br />
                        <font id="nota">El sistema Automatizado Nacional de Educación Cristiana de las Asambleas de Dios de Venezuela permitan manejar la base de datos de los Estudiantes, Institutos, Ministro de las Asambleas de Dios de Venezuela, con las herramientas adecuadas para controlar los registros y movimiento administrativos.</font><br />
					</td>
  				</tr>

                <tr>
    				<td width="750" align="center">
                        <font id="texto">
                        Recomendamos la utilización del siguiente navegadores: Google Chrome.<br />
                        Multiservicio Sistempro, C.A. - RIF: J-40351851-3 Copyright 2015. Todos los derechos reservados.<br />
                        Para Mayor Informacion: 0424-268-8338/0212-516-1174<br />
                        www.sistempro.net<br />
                        Correo: sistempro.ca@gmail.com<br />
                        
                        <img src="imagenes/sistempro.png" width="135" height="54"/>
                        </font>
					</td>
  				</tr>
		</table>

 	 </td>
    
    
    
    
    <td width="250" valign="top" align="center">
   	<div id="formulario">
    <font id="texto">Bienvenido al Sistemas Automatizado Naciona de Educación Cristiana de las Asambleas de Dios...<br /><br /><br /><br />
    
    <img src="imagenes/telefono.png" width="50" height="50"/><br />
    Soporte del Sistema <br />
    Si desea más Información o tiene alguna duda llamenos al <br />
    (0424) 268-8338<br />
    sistempro.ca@gmail.com
    </font><br />
    
    </div>
    
    
    </td>
  </tr>
</table>
	
        
</center>    
</body>
</html>
<?php include ("../pie.php")?>

