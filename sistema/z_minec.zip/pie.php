<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="estilos.css" rel="stylesheet" type="text/css" />
<link href="estilos.css" rel="stylesheet" type="text/css" />
<title>Documento sin título</title>
</head>

<body>
<center>
<table width="100%" height="350" border="0" cellspacing="0" cellpadding="0" id="tabla_pie">
  <tr>
    <td align="center" valign="top">
    		<br />
    		<font id="texto_pie">
			<table width="1000" height="100" border="1" cellspacing="0" cellpadding="0">
  				<tr valign="top">
    				<td width="200">Director Naciona: </td>
    				<td width="200">Sub-Director</td>
    				<td width="200">Secretario</td>
    				<td width="200">Administrador</td>
  					<td width="200">Vocales:</td>
  				</tr>
			</table> 
            </font>       
        	<table  width="1000" height="200" border="0" >
 				 <tr>
   					<td align="left" width="500"> 
   	 				<Img src="img/logo_minec.png" width="100" height="90"> 
   	 				<font id="texto"> 
						<br/> Ministerio de Educación Cristiana
					</font> </td>
    				<td align="right" width="500"> 
    				<Img src="img/logo_azul.png" width="180" height="70"> 
       				<font id="texto"> 
					<br/> Desarrollado por SISTEMPRO C.A
        			<br/> Todos los Derechos Reservados
        			<br/> © 2014 SISTEMPRO
        			</font>
    				</td>
 				</tr>
			</table>
    
    
    
    </td>
  </tr>
</table>







</center>
</body>
</html>